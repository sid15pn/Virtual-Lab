%% Initializing
m=1000; %mass in kg
a1=1; %length from COG to front axle in m
a2=1.5; %length from COG to front axle in m
Cf=30000; %cornering stiffness of front axle in N/rad
Cr=30000; %cornering stiffness of rear axle in N/rad
v=20; %vehicle velocity in m/s
delta = 0.1;
Iz = 1650;
Ts = 0.1;